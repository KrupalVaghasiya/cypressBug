
const practiceData = {
	addPatientLink: 'Create New Patient',
	createAccount: 'Create Account',
	Rx_productType: 'RX',
	OTC_productType: 'OTC',
	Compound_productType: 'Compound',
	paymentButtonName: 'Skip Payment',
	SelectButton: 'Select',
	continueButton: 'Continue',
	buttonTag: 'button',
	SaveandExitbutton: 'Save and Exit',
	creditCardNumber: '02a500c0170017008292;371449*****8431=3405?*50646b796dbda974c15d1b5d5aa8c23d3238783c5b041ce6000000000000000000000000000000000000000030343952303337373034ffff98765400068000283fcd03',
	CardNumber: '4111 1111 1111 1111',
	nameOnCard: 'Adma Zampa',
	cardSecurityPin: '123',
	ViewDetailsOfOrder: 'View Details',
	DropchartTitle1: 'Welcome Letter',
	DropchartTitle2: 'Patient Directions',
	invalidPhoneNumberMessage: 'Invalid phone number',
	patientApprovalButton: 'Confirm Approval',
	transferOrderButton: 'Transfer Order',
};
// export the users you created so you can import them in your tests
export { practiceData };